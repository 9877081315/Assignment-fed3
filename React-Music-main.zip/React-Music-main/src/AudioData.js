export const audios = [
  {
    name: "Satisfya",
    music:
      "https://aac.saavncdn.com/931/423b9e98db7f5ad575ee19e383d4c30e_320.mp4",
    creator: "Imran Khan",
  },

  {
    name: "Kaash",
    music:
      "https://aac.saavncdn.com/233/90bddd1c80301df15dd571d048f2c64f_320.mp4",
    creator: "Bilaal Saeed",
  },

  {
    name: "She's the one",
    music:
      "https://aac.saavncdn.com/711/ecc7fa94aae221c5131295d63ec5a69a_320.mp4",
    creator: "Jerry",
  },
];
